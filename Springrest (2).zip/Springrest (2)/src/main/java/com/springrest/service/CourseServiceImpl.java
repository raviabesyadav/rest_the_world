package com.springrest.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springrest.dao.CourseDao;
import com.springrest.entity.Course;

import jakarta.persistence.EntityNotFoundException;

@Service
public class CourseServiceImpl implements CourseService {
	
	@Autowired
	private CourseDao courseDao;
	
	  
	
  
	// List<Course>list;
	
	public CourseServiceImpl() {
		//list = new ArrayList<>();
		//list.add(new Course("329","C++ Course","It's frist course of this world"));
		//list.add(new Course("3231", "Java", "New course this one"));
		
	}
	
	@Override
	public List<Course> getCourses() {
		
				return  courseDao.findAll();
	}
	
	
	@Override
	public Course getCourse(long courseId)
	{
		//Course c = null;
		/*for(Course course : list)
		{
			if(course.getId()==courseId)
			{
				c=course;
				break;
			}
		}
		*/
		
		//return courseDao.getOne(courseId);
		// Find by ID using Optional
		Optional<Course> optionalCourse = courseDao.findById(courseId);
     
		if (optionalCourse.isPresent()) {
			
		    return optionalCourse.get(); // Return the found entity
		} else {
		    throw new EntityNotFoundException("Course not found with ID: " + courseId);
		}

	}
	
	@Override
	public Course addCourse(Course course)
	{
		//list.add(course);
		courseDao.save(course);
		return course;
	}
	
	@Override
	public Course updateCourse(Course course)
	{
		/*list.forEach(e->{
			if(e.getId()==course.getId())
			{
				e.setTitle(course.getTitle());
				e.setDiscription(course.getDiscription());
			}
		});
		*/
		courseDao.save(course);
		return course;
		
	}
	
	
	@Override
	public void coursedelete(long id)
	{
		System.out.println("hello");
		//list =this.list.stream().filter(e->e.getId()!=parseLong).collect(Collectors.toList()) ;
		
		
				//Optional<Course> entity =courseDao.findById(ParseLong);
				//courseDao.delete(entity.get());
				
				
				
				
				
				//courseDao.deleteById(ParseLong);
				
				
//				System.out.println("hello");
//				
//				Optional<Course> entity = courseDao.findById(ParseLong);
//				if (entity.isPresent()) {
//				    courseDao.delete(entity.get());
//				    System.out.println("hello");
//				} else {
//				   System.out.println("hello");
//				    System.out.println("Course with ID " + ParseLong + " not found.");
//				}
		

	   
	        courseDao.deleteById(id);
	    


	}
//	//Service
//	public List<Course>fetchAll()
//	{
//		List<Course> data =  courseDao.fetchallFromCustom();
//		return data;
//	 }

	@Override
	public List<Course> fetchAll() {
		// TODO Auto-generated method stub
		return null;
	}
	 
	

}
